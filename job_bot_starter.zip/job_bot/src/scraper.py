
import requests
from bs4 import BeautifulSoup

def fetch_indeed_jobs(query, location, limit=10):
    jobs = []
    url = f"https://www.indeed.com/jobs?q={query}&l={location}"
    res = requests.get(url)
    soup = BeautifulSoup(res.text, 'html.parser')

    for job_card in soup.select('a[data-hide-spinner="true"]')[:limit]:
        title = job_card.text.strip()
        link = f"https://www.indeed.com{job_card['href']}"
        jobs.append({'title': title, 'url': link})

    return jobs
