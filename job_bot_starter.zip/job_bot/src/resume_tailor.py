
import openai

def tailor_resume(base_resume, job_description):
    prompt = f"""
    Given this job description:\n{job_description}\n\n
    Tailor this resume:\n{base_resume}\n\n
    Focus on aligning skills, responsibilities, and measurable achievements.
    """
    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.7
    )
    return response['choices'][0]['message']['content']
