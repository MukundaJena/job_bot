
import gspread
from oauth2client.service_account import ServiceAccountCredentials

def update_sheet(job_entry):
    scope = ["https://spreadsheets.google.com/feeds",
             "https://www.googleapis.com/auth/drive"]
    creds = ServiceAccountCredentials.from_json_keyfile_name('google-credentials.json', scope)
    client = gspread.authorize(creds)

    sheet = client.open("Job Tracker").sheet1
    sheet.append_row([
        job_entry['title'],
        job_entry['url'],
        "Not Applied",  # Status
        "",             # Notes
    ])
