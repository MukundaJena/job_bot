
from src.scraper import fetch_indeed_jobs
from src.resume_tailor import tailor_resume
from src.tracker import update_sheet

if __name__ == "__main__":
    jobs = fetch_indeed_jobs("Technical Program Manager", "Seattle, WA")
    for job in jobs:
        base_resume = open("templates/base_resume.txt").read()
        tailored_resume = tailor_resume(base_resume, job['title'])
        update_sheet(job)
        # Save resume locally or trigger autofill next
